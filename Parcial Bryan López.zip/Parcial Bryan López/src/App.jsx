//Formulario de Bryan Lopez
import React, { useState } from 'react';
import './index.css';

function App() {
  const [nombre, setNombre] = useState('');
  const [animal, setAnimal] = useState('');
  const [mostrarResultado, setMostrarResultado] = useState(false);
  const [error, setError] = useState(false);

  const handleSubmit = (event) => {
    event.preventDefault();

    // Validaciones
    if (nombre.trim().length < 3 || animal.length < 6) {
      setError('Por favor, asegúrate de que el nombre tenga al menos 3 caracteres y el animal al menos 6.');
      setMostrarResultado(false);
    } else {
      setError(null);
      setMostrarResultado(true);
      console.log('Nombre:', nombre);
      console.log('Animal:', animal);
    }
  };
  return (
    <div class='container'>
      <h2 class='titulo'>Elige un animal</h2>
      <form onSubmit={handleSubmit} class='formulario'>
        <label>
          Ingresa tu nombre:
          <input
            type="text"
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
          />
        </label>
        <br />
        <label>
          Ingresa tu animal favorito:
          <input
            type="text"
            value={animal}
            onChange={(e) => setAnimal(e.target.value)}
          />
        </label>
        <br />
        <button type="submit">ENVIAR</button>
        {error && <p>Por favor chequea que la información sea correcta</p>}
      </form>

      {mostrarResultado && (
        <div class="contenedor" className="resultado">
          <p>Hola {nombre}!</p>
          <p>Sabemos que tu animal favorito es:</p>
          <button style={{ backgroundColor: 'aqua', borderRadius: '25px' }}>{animal}</button>
        </div>
      )}
    </div>
  );
}

export default App;

