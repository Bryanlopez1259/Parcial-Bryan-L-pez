
function Card({ nombre, animal }) {
  return (
    <div className="card">
      <h3>{nombre}</h3>
      <p>Animal: {animal}</p>
    </div>
  );
}

export default Card;
